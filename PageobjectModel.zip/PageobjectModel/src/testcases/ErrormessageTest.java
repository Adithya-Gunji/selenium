package testcases;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import library.Loginpage;
import utils.Apputils;

public class ErrormessageTest extends Apputils{

	@Test
	@Parameters({"invaliduid","invalidpwd"})
	public void checkErrormessage(String uid,String pwd) throws InterruptedException
	{
		 Loginpage lp = PageFactory.initElements(driver,Loginpage.class);
	     lp.login(uid,pwd);
	     
	     Thread.sleep(4000);
	 boolean res    = lp.isErrorMessageDisplayed();
	 
	      Assert.assertTrue(res);
	}
}
