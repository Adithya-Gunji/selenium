package testcases;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import library.Loginpage;
import utils.Apputils;

public class AdminLoginTest extends Apputils{
	
	@Test
	@Parameters({"adminuid","adminpwd"})
	public void checkAdminLogin(String uid,String pwd) throws InterruptedException {
		
	
	     Loginpage lp = PageFactory.initElements(driver,Loginpage.class);
	     lp.login(uid,pwd);
	     
	boolean res      = lp.isAdminModuleDisplayed();
	     
	       Assert.assertTrue(res);
	       
	       Thread.sleep(3000);
	       lp.logout();
	}

}