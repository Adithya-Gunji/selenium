package library;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import utils.Apputils;

public class Loginpage{

	//Elements
	
		@FindBy(id="txtUsername")
		WebElement uid;
		
		@FindBy(id="txtPassword")
		WebElement pwd;
		
		@FindBy(xpath = "//*[@name='Submit']")
		WebElement login;
		
		@FindBy(linkText ="Admin")
		WebElement admin;
		
		@FindBy(partialLinkText ="Welcome")
		WebElement welcome;
		
		@FindBy(linkText ="Logout")
		WebElement logout;
		
		@FindBy(id="spanMessage")
		WebElement errmsg;
		
		//Functions
		
		public void login(String uname,String pword)
		{
			uid.sendKeys(uname);
			pwd.sendKeys(pword);
			
			login.click();
		}
		
		public boolean isAdminModuleDisplayed()
		{
			if(admin.isDisplayed())
			{
				return true;
			}else {
				return false;
			}
		}
		public void logout()
		{
			welcome.click();
			logout.click();
			
		}
		public boolean isErrorMessageDisplayed()
		{
			if(errmsg.isDisplayed())
			{
				return true;
			}else {
				return false;
			}
		}
}
